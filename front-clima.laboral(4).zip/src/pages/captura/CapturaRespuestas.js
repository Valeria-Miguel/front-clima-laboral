// src/pages/captura/CapturaRespuestas.js

import React, { useState, useEffect } from 'react';
import ApiConfig from '../../apiConfig';
import '../../styles/CapturaRespuestas.css';

export default function CapturaRespuestas() {
  const [form, setForm] = useState({
    participanteCodigo: '',
    cuestionarioId: '',
    metadata: {
      adscripcion: '',
      area: '',
      puesto: '',
      nivel: '',
      antiguedad: '',
      tipoContrato: '',
      escolaridad: '',
      sexo: '',
      edad: ''
    },
    respuestas: []
  });
  const [reactivos, setReactivos] = useState([]);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Cuando cambie el ID de cuestionario, cargamos los reactivos
  useEffect(() => {
    const load = async () => {
      if (!form.cuestionarioId.trim()) {
        setReactivos([]);
        return;
      }
      try {
        const res = await fetch(
          `${ApiConfig.baseURL}/respuestas/reactivos/${form.cuestionarioId}`
        );
        const data = await res.json();
        if (!res.ok) throw new Error(data.message || 'Error al cargar reactivos');
        setReactivos(data);
        setError('');
      } catch (err) {
        setError(err.message);
      }
    };
    load();
  }, [form.cuestionarioId]);

  const handleMeta = e => {
    const { name, value } = e.target;
    setForm(f => ({
      ...f,
      metadata: { ...f.metadata, [name]: value }
    }));
  };

  const handleResp = (reactivoId, valor) => {
    setForm(f => {
      const sinEste = f.respuestas.filter(r => r.reactivoId !== reactivoId);
      return {
        ...f,
        respuestas: [...sinEste, { reactivoId, valor }]
      };
    });
  };

  const registrar = async () => {
    if (!form.participanteCodigo.trim() || !form.cuestionarioId.trim()) {
      setError('Código y ID de cuestionario obligatorios.');
      return;
    }
    if (form.respuestas.length !== reactivos.length) {
      setError('Debes responder todos los reactivos.');
      return;
    }

    try {
      const res = await fetch(
        `${ApiConfig.baseURL}/respuestas/capturar`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(form)
        }
      );
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || 'Error al guardar');
      setSuccess('Respuestas guardadas correctamente');
      setError('');
      // opcional: limpiar formulario aquí
    } catch (err) {
      setError(err.message);
      setSuccess('');
    }
  };

  return (
    <div className="captura-page">
      <h2>Captura de Respuestas</h2>
      <div className="form-group">
        <label>Código de Participante:</label>
        <input
          value={form.participanteCodigo}
          onChange={e => setForm(f => ({ ...f, participanteCodigo: e.target.value }))}
          className="registro-input"
        />
      </div>
      <div className="form-group">
        <label>ID del Cuestionario:</label>
        <input
          value={form.cuestionarioId}
          onChange={e => setForm(f => ({ ...f, cuestionarioId: e.target.value }))}
          className="registro-input"
        />
      </div>

      <h3>Metadatos</h3>
      {Object.entries(form.metadata).map(([k, v]) => (
        <div key={k} className="form-group">
          <label>{k.charAt(0).toUpperCase() + k.slice(1)}:</label>
          <input
            name={k}
            value={v}
            onChange={handleMeta}
            className="registro-input"
          />
        </div>
      ))}

      {reactivos.length > 0 && (
        <>
          <h3>Respuestas</h3>
          <div className="reactivos-list">
            {reactivos.map(r => (
              <div key={r._id} className="reactivo-item">
                <span>{r.texto}</span>
                <select
                  onChange={e => handleResp(r._id, +e.target.value)}
                  className="registro-input"
                >
                  <option value="">--</option>
                  {[0,1,2,3,4].map(v => (
                    <option key={v} value={v}>{v}</option>
                  ))}
                </select>
              </div>
            ))}
          </div>
        </>
      )}

      {error && <p className="error-text">{error}</p>}
      {success && <p className="success-text">{success}</p>}

      <button onClick={registrar} className="btn-primary">Guardar Respuestas</button>
    </div>
  );
}
