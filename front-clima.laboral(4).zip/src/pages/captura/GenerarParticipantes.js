// src/pages/captura/GenerarParticipantes.js

import React, { useState } from 'react';
import ApiConfig from '../../apiConfig';
import '../../styles/CapturaRespuestas.css';

export default function GenerarParticipantes() {
  const [cuestId, setCuestId] = useState('');
  const [cantidad, setCantidad] = useState(1);
  const [codigos, setCodigos] = useState([]);
  const [error, setError] = useState('');

  const generar = async () => {
    if (!cuestId.trim() || cantidad < 1) {
      setError('ID de cuestionario y cantidad válidos.');
      return;
    }
    try {
      const res = await fetch(
        `${ApiConfig.baseURL}/respuestas/participantes/generar`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ cuestionarioId: cuestId, cantidad }),
        }
      );
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || 'Error al generar códigos');
      setCodigos(data.codigos);
      setError('');
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="captura-page">
      <h2>Generar Códigos de Participantes</h2>
      <div className="form-group">
        <label>ID del Cuestionario:</label>
        <input
          value={cuestId}
          onChange={e => setCuestId(e.target.value)}
          className="registro-input"
        />
      </div>
      <div className="form-group">
        <label>Cantidad:</label>
        <input
          type="number"
          min="1"
          value={cantidad}
          onChange={e => setCantidad(+e.target.value)}
          className="registro-input"
        />
      </div>
      {error && <p className="error-text">{error}</p>}
      <button onClick={generar} className="btn-primary">Generar</button>

      {codigos.length > 0 && (
        <ul className="codigo-list">
          {codigos.map(c => <li key={c}>{c}</li>)}
        </ul>
      )}
    </div>
  );
}
