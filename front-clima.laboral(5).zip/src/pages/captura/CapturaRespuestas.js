// src/pages/captura/CapturaRespuestas.js

import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import ApiConfig from '../../apiConfig';
import '../../styles/CapturaRespuestas.css';

export default function CapturaRespuestas() {
  const navigate  = useNavigate();
  const location  = useLocation();
  const prevState = location.state || {};

  // Wizard step control
  const [step, setStep]                 = useState(1);
  const [cuestionarios, setCuestionarios] = useState([]);
  const [reactivos, setReactivos]       = useState([]);
  const [error, setError]               = useState('');
  const [success, setSuccess]           = useState('');

  // Form state
  const [form, setForm] = useState({
    participanteCodigo: prevState.codigo || '',
    cuestionarioId:      prevState.cuestionarioId || '',
    metadata: {
      sexo: '',
      edad: '',
      estadoCivil: '',
      nivelEstudios: '',
      adscripcion: '',
      area: '',
      puestoNivel: '',
      tipoPuesto: '',
      tipoContrato: '',
      tipoPersonal: '',
      jornada: '',
      rotacion: '',
      experiencia: '',
      tiempoPuesto: '',
      instruccionAbierta: ''
    },
    respuestas: []  // { reactivoId, valor }
  });

  // Load cuestionarios for dropdown
  useEffect(() => {
    fetch(`${ApiConfig.baseURL}/cuestionarios`)
      .then(res => { if (!res.ok) throw new Error('Error al cargar cuestionarios'); return res.json(); })
      .then(setCuestionarios)
      .catch(err => setError(err.message));
  }, []);

  // Load NOM-035 reactivos when a cuestionario is selected
  useEffect(() => {
    if (!form.cuestionarioId) return;
    fetch(`${ApiConfig.baseURL}/cuestionarios/nom035/reactivos`)
      .then(res => { if (!res.ok) throw new Error('No se pudieron cargar los reactivos'); return res.json(); })
      .then(setReactivos)
      .catch(err => setError(err.message));
  }, [form.cuestionarioId]);

  // Handle metadata selects and textarea
  const handleMeta = e => {
    const { name, value } = e.target;
    setForm(f => ({ ...f, metadata: { ...f.metadata, [name]: value } }));
  };

  // Handle selecting a score for a reactivo
  const handleResp = (reactivoId, valor) => {
    setForm(f => {
      const others = f.respuestas.filter(r => r.reactivoId !== reactivoId);
      return { ...f, respuestas: [...others, { reactivoId, valor }] };
    });
  };

  // STEP 1: Participant code and cuestionario selection
  const Step1 = () => (
    <>
      <div className="form-group">
        <label>Código de Participante:</label>
        <input
          value={form.participanteCodigo}
          onChange={e => setForm(f => ({ ...f, participanteCodigo: e.target.value }))}
          className="registro-input"
        />
      </div>
      <div className="form-group">
        <label>Cuestionario:</label>
        <select
          value={form.cuestionarioId}
          onChange={e => setForm(f => ({ ...f, cuestionarioId: e.target.value }))}
          className="registro-input"
        >
          <option value="">-- Selecciona uno --</option>
          {cuestionarios.map(c => (
            <option key={c._id} value={c._id}>{c.nombre}</option>
          ))}
        </select>
      </div>
      <div className="wizard-buttons">
        <button onClick={() => setStep(2)} className="btn-primary">Siguiente</button>
      </div>
    </>
  );

  // STEP 2: Metadata (Guía V) and open instruction textarea
  const Step2 = () => (
    <>
      <h3>Metadatos (Guía V)</h3>
      {/* Sexo */}
      <div className="form-group">
        <label>Sexo:</label>
        <select name="sexo" value={form.metadata.sexo} onChange={handleMeta} className="registro-input">
          <option value="">-- Selecciona --</option>
          <option value="Masculino">Masculino</option>
          <option value="Femenino">Femenino</option>
        </select>
      </div>
      {/* Edad */}
      <div className="form-group">
        <label>Edad en años:</label>
        <select name="edad" value={form.metadata.edad} onChange={handleMeta} className="registro-input">
          <option value="">-- Selecciona rango --</option>
          {['15-19','20-24','25-29','30-34','35-39','40-44','45-49','50-54','55-59','60-64','65-69','70 o más']
            .map(r => <option key={r} value={r}>{r}</option>)}
        </select>
      </div>
      {/* Estado Civil */}
      <div className="form-group">
        <label>Estado Civil:</label>
        <select name="estadoCivil" value={form.metadata.estadoCivil} onChange={handleMeta} className="registro-input">
          <option value="">-- Selecciona --</option>
          <option value="Casado">Casado</option>
          <option value="Soltero">Soltero</option>
          <option value="Unión libre">Unión libre</option>
          <option value="Divorciado">Divorciado</option>
          <option value="Viudo">Viudo</option>
        </select>
      </div>
      {/* Nivel de Estudios */}
      <div className="form-group">
        <label>Nivel de Estudios:</label>
        <select name="nivelEstudios" value={form.metadata.nivelEstudios} onChange={handleMeta} className="registro-input">
          <option value="">-- Selecciona --</option>
          {[
            'Sin formación','Primaria terminada','Primaria incompleta',
            'Secundaria terminada','Secundaria incompleta',
            'Preparatoria terminada','Preparatoria incompleta',
            'Técnico Superior terminada','Técnico Superior incompleta',
            'Licenciatura terminada','Licenciatura incompleta',
            'Maestría terminada','Maestría incompleta',
            'Doctorado terminada','Doctorado incompleta'
          ].map(n => <option key={n} value={n}>{n}</option>)}
        </select>
      </div>
      {/* Adscripción (Matriz/Sucursal) */}
      <div className="form-group">
        <label>Matriz / Sucursal:</label>
        <select name="adscripcion" value={form.metadata.adscripcion} onChange={handleMeta} className="registro-input">
          <option value="">-- Selecciona --</option>
          <option value="Norte">Norte</option>
          <option value="Sur">Sur</option>
          <option value="Noreste">Noreste</option>
          <option value="Noroeste">Noroeste</option>
          <option value="Otras">Otras</option>
        </select>
      </div>
      {/* Área */}
      <div className="form-group">
        <label>Departamento / Área:</label>
        <select name="area" value={form.metadata.area} onChange={handleMeta} className="registro-input">
          <option value="">-- Selecciona --</option>
          {[
            'Administración','Producción','Logística','Compras','Ventas',
            'Mercadotecnia','Finanzas','Recursos Humanos','Mantenimiento'
          ].map(a => <option key={a} value={a}>{a}</option>)}
        </select>
      </div>
      {/* Puesto / Nivel */}
      <div className="form-group">
        <label>Puesto / Nivel:</label>
        <select name="puestoNivel" value={form.metadata.puestoNivel} onChange={handleMeta} className="registro-input">
          <option value="">-- Selecciona --</option>
          {[
            'Ayudante general','Operador de producción','Mecánico',
            'Supervisor de producción','Jefatura','Líder','Gerencia','Dirección'
          ].map(p => <option key={p} value={p}>{p}</option>)}
        </select>
      </div>
      {/* Tipo de puesto */}
      <div className="form-group">
        <label>Tipo de puesto:</label>
        <select name="tipoPuesto" value={form.metadata.tipoPuesto} onChange={handleMeta} className="registro-input">
          <option value="">-- Selecciona --</option>
          {['Operativo','Supervisor','Profesional técnico','Gerente'].map(t => <option key={t} value={t}>{t}</option>)}
        </select>
      </div>
      {/* Tipo de contratación */}
      <div className="form-group">
        <label>Tipo de contratación:</label>
        <select name="tipoContrato" value={form.metadata.tipoContrato} onChange={handleMeta} className="registro-input">
          <option value="">-- Selecciona --</option>
          {['Por obra o proyecto','Por tiempo determinado','Tiempo indeterminado','Honorarios'].map(t => <option key={t} value={t}>{t}</option>)}
        </select>
      </div>
      {/* Tipo de personal */}
      <div className="form-group">
        <label>Tipo de personal:</label>
        <select name="tipoPersonal" value={form.metadata.tipoPersonal} onChange={handleMeta} className="registro-input">
          <option value="">-- Selecciona --</option>
          {['Sindicalizado','Confianza','Ninguno'].map(t => <option key={t} value={t}>{t}</option>)}
        </select>
      </div>
      {/* Jornada de trabajo */}
      <div className="form-group">
        <label>Tipo de jornada de trabajo:</label>
        <select name="jornada" value={form.metadata.jornada} onChange={handleMeta} className="registro-input">
          <option value="">-- Selecciona --</option>
          {['Fijo nocturno (20:00-6:00)','Fijo diurno (6:00-20:00)','Fijo mixto'].map(j => <option key={j} value={j}>{j}</option>)}
        </select>
      </div>
      {/* Rotación de turnos */}
      <div className="form-group">
        <label>Realiza rotación de turnos:</label>
        <select name="rotacion" value={form.metadata.rotacion} onChange={handleMeta} className="registro-input">
          <option value="">-- Selecciona --</option>
          <option value="Si">Si</option>
          <option value="No">No</option>
        </select>
      </div>
      {/* Experiencia laboral */}
      <div className="form-group">
        <label>Tiempo de experiencia laboral:</label>
        <select name="experiencia" value={form.metadata.experiencia} onChange={handleMeta} className="registro-input">
          <option value="">-- Selecciona --</option>
          {['Menos de 6 meses','6 meses a 1 año','1 a 4 años','5 a 9 años','10 a 14 años','15 a 19 años','20 a 24 años','25 años o más'].map(e => <option key={e} value={e}>{e}</option>)}
        </select>
      </div>
      {/* Tiempo en el puesto actual */}
      <div className="form-group">
        <label>Tiempo en el puesto actual:</label>
        <select name="tiempoPuesto" value={form.metadata.tiempoPuesto} onChange={handleMeta} className="registro-input">
          <option value="">-- Selecciona --</option>
          {['Menos de 6 meses','6 meses a 1 año','1 a 4 años','5 a 9 años','10 a 14 años','15 a 19 años','20 a 24 años','25 años o más'].map(t => <option key={t} value={t}>{t}</option>)}
        </select>
      </div>
      {/* Instrucción abierta */}
      <div className="form-group">
        <label>Instrucción abierta:</label>
        <textarea name="instruccionAbierta" value={form.metadata.instruccionAbierta} onChange={handleMeta} className="registro-input" />
      </div>
      <div className="wizard-buttons">
        <button onClick={() => setStep(1)} className="btn-secondary">Atrás</button>
        <button onClick={() => setStep(3)} className="btn-primary">Siguiente</button>
      </div>
    </>
  );

  // STEP 3: Closed responses with identifiers
  const Step3 = () => {
    // Split responses by seccionId
    const guiaI = [], guiaII = [], guiaIII = [];
    form.respuestas.forEach(r => {
      const meta = reactivos.find(x => x._id === r.reactivoId);
      if (!meta) return;
      const obj = { idPregunta: r.reactivoId, valor: r.valor };
      if (meta.seccionId === 1) guiaI.push(obj);
      else if (meta.seccionId === 2) guiaII.push(obj);
      else if (meta.seccionId === 3) guiaIII.push(obj);
    });

    const registrar = async () => {
      setError(''); setSuccess('');
      const { participanteCodigo, cuestionarioId, metadata } = form;
      if (!participanteCodigo || !cuestionarioId) { setError('Código y cuestionario obligatorios'); setStep(1); return; }
      if (reactivos.length !== form.respuestas.length) { setError('Debes responder todas las preguntas'); setStep(3); return; }

      const payload = { participanteCodigo, cuestionarioId, guiaI, guiaII, guiaIII, guiaV: metadata };
      try {
        const res = await fetch(`${ApiConfig.baseURL}/respuestas/capturar`, {
          method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.message || 'Error al guardar respuestas');
        setSuccess('Respuestas guardadas correctamente');
        // Tracking completion
        await fetch(`${ApiConfig.baseURL}/participantes/completado`, {
          method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ participanteCodigo: form.participanteCodigo, cuestionarioId: form.cuestionarioId })
        });
        setTimeout(() => navigate('/captura/generar'), 1500);
      } catch (err) {
        setError(err.message);
      }
    };

    return (
      <>
        <h3>Respuestas</h3>
        <div className="reactivos-list">
          {reactivos.map(r => {
            const current = form.respuestas.find(x => x.reactivoId === r._id);
            return (
              <div key={r._id} className="reactivo-item">
                <span>{`[Sección ${r.seccionId}] ${r.texto}`}</span>
                <select value={current?.valor ?? ''} onChange={e => handleResp(r._id, +e.target.value)} className="registro-input">
                  <option value="">--</option>
                  {[0,1,2,3,4].map(v => <option key={v} value={v}>{v}</option>)}
                </select>
              </div>
            );
          })}
        </div>
        <div className="wizard-buttons">
          <button onClick={() => setStep(2)} className="btn-secondary">Atrás</button>
          <button onClick={registrar} className="btn-primary">Guardar</button>
        </div>
      </>
    );
  };

  return (
    <div className="captura-page">
      <h2>Captura de Respuestas</h2>
      {error   && <p className="error-text">{error}</p>}
      {success && <p className="success-text">{success}</p>}
      {step === 1 && <Step1 />}
      {step === 2 && <Step2 />}
      {step === 3 && <Step3 />}
    </div>
  );
}
